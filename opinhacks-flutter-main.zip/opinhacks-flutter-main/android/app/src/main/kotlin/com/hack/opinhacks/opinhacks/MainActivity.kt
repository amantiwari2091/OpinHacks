package com.hack.opinhacks.opinhacks

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
